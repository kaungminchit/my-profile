
// Simple fade-in animation on scroll
const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
});

document.querySelectorAll('.glass-card').forEach(card => {
    observer.observe(card);
});

// Add fade-in effect class
const style = document.createElement('style');
style.innerHTML = `
.glass-card {
    opacity: 0;
    transform: translateY(30px);
    transition: all 0.6s ease-out;
}
.glass-card.visible {
    opacity: 1;
    transform: translateY(0);
}
`;
document.head.appendChild(style);
